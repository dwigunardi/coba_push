const hitungPersegi = (Luas) => {
    return Luas * 4
}

export{hitungPersegi}
