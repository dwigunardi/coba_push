const hitungSegitiga = (sisi) => {
    return sisi * 3
}

export{hitungSegitiga}