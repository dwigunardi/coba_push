import { hitungPersegi } from "./js3.js";
import { hitungSegitiga } from "./js4.js";
const hasil1 = hitungPersegi(5)
const hasil2 = hitungSegitiga(5)
console.log("hasil Dari Luas Persegi",hasil1)
console.log("hasil Dari Luas Persegi",hasil2)